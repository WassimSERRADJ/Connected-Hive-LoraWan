/*
Author: Robert Lie (mobilefish.com)
The config.js file contains the MySQL user credentials and The Things Network (TTN) appID and accessKey.
See LoRa/LoRaWAN Tutorial 27
https://www.mobilefish.com/download/lora/lora_part27.pdf

The config.js file is used by:
- drop_db.js
- create_db.js
- create_table.js
- store_records.js
- read_table.js
- retrieve.js
- send.js
*/
const databaseOptions = {
    host: 'localhost',
    user: 'root',
    password: ''
};

const TTNOptions = {
    appID: 'projet_poc_test1',
    accessKey: 'ttn-account-v2.hy8BP0srvfox7bI0My7A3PN9VDx3HoUAl8_o55FQCoA'
};
module.exports = {databaseOptions: databaseOptions, TTNOptions: TTNOptions};
